# Dovuq Encode & Decode Tool

## 1 About

Dovuq Encode & Decode Tool (DEDT) is a program for Windows by Dovuq to help encode and decode files, but only for plain texts. If you use this to encode executable files, docs and so on, you will probably not be able to execute it after decoding.

## 2 How to use

### 2.1 Ready to use

Unlike other programs, you cannot use dedt just by double-clicking the executable file, dedt.exe. Instead, you have to open this program like this:

First, unzip, and add the program to the environment variable. Search on the web for details.

Next, Press Win+R, input "cmd", and press enter to get into cmd mode.

Then, you are ready to use dedt.

### 2.2 Encoding & Decoding

After doing those above, you can use dedt by inputting "dedt"+command. For example, you can input "dedt help" for help.

In order to encode a file, you can input "dedt help encode". It will tell you how to encode a file, like this:

dedt encode <source> <saveplace> <key>
This is used to encode a file.
source    : the file you want to encode
saveplace : the file you want to save the result
            will be created if not exists
key       : the key to encode

This is how you encode a file. For example, you want to encode "1.txt", and save the result at "2.txt", the key is "this is dedt", so you can input:

dedt encode 1.txt 2.txt "this is dedt"

Tips:

- If your key consists spaces, quote the whole key. If not, you don't have to quote it. In the same way, if spaces exist in your file's name, quote it.
- You must turn to the directory that includes the file you want to encode first. Search on the web for details.
- You can use the keys below, or use your own keys as well:
  - this is dedt
  - xrdrspakioi
  - alice in wonderland
  - your birthday
- The key is not recommanded to be too short or too long, and only letters are useful as the key.

After a while (if your file is not too big), open 2.txt, you can see that it was already successfully encoded.

This is the way to encode. The way to decode is similar.

### 2.3 Updates

View updates at https://dovuq.github.io/programs/dedt

## 3 Copyright

Copyright by Dovuq.
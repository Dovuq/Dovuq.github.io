#ifndef Dovuq_Bigint_H
#define Dovuq_Bigint_H
#define templ template <class T>
using namespace std;
namespace Bigint
{
	struct bigint
	{
		unsigned long long n,a[10005];
		bigint operator= (unsigned long long p)
		{
			n=0;
			while (p)
			{
				a[n++]=p%10;
				p/=10;
			}
			return *this;
		}
		bigint (unsigned long long p=0)
		{
			*this=p;
		}
	};
	
	istream& operator>> (istream& is,bigint& a)
	{
		a.n=0;
		char s[10005];
		is>>s;
		if (s=="0") return is;
		a.n=strlen(s);
		for (int i=0;i<a.n;i++)
			a.a[i]=s[a.n-i-1]-'0';
		return is;
	}
	ostream& operator<< (ostream& os,bigint a)
	{
		if (a.n)
			for (int i=a.n-1;i>=0;i--)
				os<<a.a[i];
		else os<<0;
		return os;
	}
	
	templ bigint operator+ (bigint a,T c)
	{
		bigint b=c;
		if (a.n<b.n) swap(a,b);
		a.a[a.n]=0;
		for (int i=b.n-1;i>=0;i--)
			a.a[i]+=b.a[i];
		for (int i=0;i<a.n;i++)
			if (a.a[i]>=10)
			{
				a.a[i]-=10;
				a.a[i+1]++;
			}
		if (a.a[a.n]) a.n++;
		return a;
	}
	templ bigint operator+= (bigint& a,T b)
	{
		return a=a+b;
	}
	
	templ bigint operator- (bigint a,T c)
	{
		bigint b=c;
		for (int i=b.n-1;i>=0;i--)
			a.a[i]-=b.a[i];
		for (int i=0;i<a.n;i++)
			if (a.a[i]<0)
			{
				a.a[i]+=10;
				a.a[i+1]--;
			}
		while (a.n>0 && !a.a[a.n-1]) a.n--;
		return a;
	}
	templ bigint operator-= (bigint& a,T b)
	{
		return a=a-b;
	}
	
	templ bigint operator* (bigint a,T b)
	{
		for (int i=a.n-1;i>=0;i--)
			a.a[i]*=b;
		for (int i=0;i<a.n || a.a[i];i++)
			if (a.a[i]>=10)
			{
				if (i+1>=a.n) a.a[i+1]=0,a.n++;
				a.a[i+1]+=a.a[i]/10;
				a.a[i]%=10;
			}
		return a;
	}
	templ bigint operator*= (bigint& a,T b)
	{
		return a=a*b;
	}
	
	templ bool operator< (bigint a,T c)
	{
		bigint b=c;
		if (a.n==b.n)
			for (int i=a.n-1;i>=0;i++)
				if (a.a[i]!=b.a[i])
					return a.a[i]<b.a[i];
		return a.n<b.n;
	}
	templ bool operator> (bigint a,T b)
	{
		return b<a;
	}
	templ bool operator!= (bigint a,T b)
	{
		return a<b || b<a;
	}
	templ bool operator== (bigint a,T b)
	{
		return !(a!=b);
	}
	templ bool operator<= (bigint a,T b)
	{
		return !(a>b);
	}
	templ bool operator>= (bigint a,T b)
	{
		return !(a<b);
	}
}
using namespace Bigint;
#undef templ
#endif

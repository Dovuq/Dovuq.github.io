#ifndef Dovuq_SegmentTree_H
#define Dovuq_SegmentTree_H
struct SegmentTree_Sum
{
    int val[400005],tag[400005];
    void build (int i,int l,int r,int* a)
    {
        if (l>r) return;
        if (l==r)
        {
            val[i]=a[l];
            return;
        }
        int mid=(l+r)>>1;
        build (i<<1,l,mid,a);
        build (i<<1|1,mid+1,r,a);
        val[i]=val[i<<1]+val[i<<1|1];
    }
    void pushdown (int i,int l,int r)
    {
        tag[i<<1]+=tag[i];
        tag[i<<1|1]+=tag[i];
        val[i]+=tag[i]*(r-l+1);
        tag[i]=0;
    }
    int query (int i,int l,int r,int x,int y)
    {
        if (l>=x && r<=y)
            return val[i]+tag[i]*(r-l+1);
        if (l>y || r<x) return 0;
        pushdown (i,l,r);
        int mid=(l+r)>>1;
        return query(i<<1,l,mid,x,y)+query(i<<1|1,mid+1,r,x,y);
    }
    void add (int i,int l,int r,int x,int y,int a)
    {
        if (l>=x && r<=y)
        {
            tag[i]+=a;
            return;
        }
        if (l>y || r<x) return;
        pushdown (i,l,r);
        int mid=(l+r)>>1;
        add (i<<1,l,mid,x,y,a);
        add (i<<1|1,mid+1,r,x,y,a);
        val[i]=val[i<<1]+val[i<<1|1]+tag[i<<1]*(mid-l+1)+tag[i<<1|1]*(r-mid);
    }
};

struct SegmentTree_Max
{
    int val[400005],tag[400005];
    void build (int i,int l,int r,int* a)
    {
        if (l>r) return;
        if (l==r)
        {
            val[i]=a[l];
            return;
        }
        int mid=(l+r)>>1;
        build (i<<1,l,mid,a);
        build (i<<1|1,mid+1,r,a);
        val[i]=std::max(val[i<<1],val[i<<1|1]);
    }
    void pushdown (int i,int l,int r)
    {
        tag[i<<1]+=tag[i];
        tag[i<<1|1]+=tag[i];
        val[i]+=tag[i];
        tag[i]=-1000000010;
    }
    int query (int i,int l,int r,int x,int y)
    {
        if (l>=x && r<=y)
            return val[i]+tag[i];
        if (l>y || r<x) return 0;
        pushdown (i,l,r);
        int mid=(l+r)>>1;
        return std::max(query(i<<1,l,mid,x,y),query(i<<1|1,mid+1,r,x,y));
    }
    void add (int i,int l,int r,int x,int y,int a)
    {
        if (l>=x && r<=y)
        {
            tag[i]+=a;
            return;
        }
        if (l>y || r<x) return;
        pushdown (i,l,r);
        int mid=(l+r)>>1;
        add (i<<1,l,mid,x,y,a);
        add (i<<1|1,mid+1,r,x,y,a);
        val[i]=std::max(val[i<<1]+tag[i<<1],+val[i<<1|1]+tag[i<<1|1]);
    }
};
#endif
